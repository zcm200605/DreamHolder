DEBUG = True
HOST = '0.0.0.0'
JSON_AS_ASCII = False
SQLALCHEMY_TRACK_MODIFICATIONS = True
SECRET_KEY = 'zhangcongmian1234567890'
#定时器
SCHEDULER_API_ENABLED = True

#数据库配置
# HOSTNAME = '47.113.227.202' 项目测试内部远程服务器
HOSTNAME = '127.0.0.1'
PORT = '3306'
DATABASE = 'stu_forum'
# 项目部署时，此处请更换成本地数据库的用户名和密码
USERNAME = 'root'
PASSWORD = 'zcmzcm'
DB_URI = 'mysql+pymysql://{}:{}@{}:{}/{}?charset=utf8'.format(USERNAME, PASSWORD, HOSTNAME, PORT, DATABASE)
SQLALCHEMY_DATABASE_URI = DB_URI

#邮箱配置
MAIL_SERVER = 'smtp.qq.com'
MAIL_PORT = '465'
MAIL_USE_TLS = False
MAIL_USE_SSL = True
MAIL_DEBUG = True
MAIL_USERNAME = 'zhangcongmian@qq.com'
MAIL_PASSWORD = 'shvsxkmaieagehee'
MAIL_DEFAULT_SENDER = 'zhangcongmian@qq.com'













