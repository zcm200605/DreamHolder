from datetime import date,datetime
from utils import db

'''
导入模型需要命令行三步走：
1.flask db init
2.flask db migrate
3.flask db upgrade
'''
class MailCaptchaModel(db.Model):
    __tablename__ = 'email_captcha'
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    email = db.Column(db.String(100),nullable=True,unique=True)
    captcha = db.Column(db.String(10),nullable=True)
    create_time = db.Column(db.Date,default=date.today())


class UserModel(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(50))
    sex = db.Column(db.String(10), default='男')
    classroom = db.Column(db.String(10), default='高一一班')
    email = db.Column(db.String(50), unique=True)
    password = db.Column(db.String(200))
    height = db.Column(db.Integer, default=170)
    weight = db.Column(db.Integer, default=70)
    join_time = db.Column(db.Date,default=date.today())
    level = db.Column(db.Integer, default=0)

class WebCount(db.Model):
    __tablename__ = 'web_count'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    count = db.Column(db.Integer, default=0)

class TopicModel(db.Model):
    __tablename__ = 'topic'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    title = db.Column(db.String(50), nullable=False)
    type = db.Column(db.String(50), nullable=False)
    content = db.Column(db.Text, nullable=False)
    create_time = db.Column(db.Date, default=date.today())
    secrecy = db.Column(db.Integer, default=0)

    author_id = db.Column(db.Integer,db.ForeignKey("user.id"))
    author = db.relationship("UserModel",backref="topics")

class CommentModel(db.Model):
    __tablename__ = 'comment'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    comment = db.Column(db.Text)
    attitude = db.Column(db.String(50))
    create_time = db.Column(db.Date, default=date.today())
    sentiment = db.Column(db.String(50), default='normal')
    emotion = db.Column(db.Float, default='0')
    # 外键
    topic_id = db.Column(db.Integer, db.ForeignKey("topic.id"))
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    # （relationship）一个话题、用户下可反向引用到多个comment
    topic = db.relationship("TopicModel",backref=db.backref("comments",order_by=create_time.desc()))
    user = db.relationship("UserModel",backref="comments")

class BrowseRecord(db.Model):
    __tablename__ = 'browse_record'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    create_time = db.Column(db.Date, default=date.today())

    topic_id = db.Column(db.Integer, db.ForeignKey("topic.id"))
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    # （relationship）一个话题、用户下可反向引用到多个comment
    topic = db.relationship("TopicModel", backref="browse_records")
    user = db.relationship("UserModel", backref="browse_records")

class EmotionDaily(db.Model):
    __tablename__ = 'emotion_daily'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    emo_sum = db.Column(db.Float)
    data_num = db.Column(db.Integer)
    date = db.Column(db.Date, default=date.today())

    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    user = db.relationship("UserModel", backref="emotions")

class BehaviorDaily(db.Model):
    __tablename__ = 'behavior_daily'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    classroom = db.Column(db.String(50))
    behavior = db.Column(db.String(50))
    part = db.Column(db.Integer)
    count = db.Column(db.Integer)
    imgPath = db.Column(db.String(100))
    datetime = db.Column(db.Date, default=datetime.now())