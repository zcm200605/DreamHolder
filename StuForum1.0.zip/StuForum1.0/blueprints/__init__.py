from .forum.user import bp as user_bp
from .forum.topic import bp as topic_bp
from .manager.index import bp as index_bp
from .manager.mind import bp as mind_bp
from .manager.body import bp as body_bp
from .manager.forum import bp as forum_bp
from .manager.specific import bp as specific_bp