from flask import Blueprint, render_template, request, g, redirect, url_for, flash, session
from utils import db
from blueprints.forms import TopicForm, CommentForm
from models import TopicModel, CommentModel, BrowseRecord, UserModel, EmotionDaily, WebCount
from utils import login_required
from sqlalchemy import or_
from algorithm.nlp.senta_lstm import senta_lstm
from datetime import date,datetime
# 分页
from flask_paginate import Pagination, get_page_parameter

bp = Blueprint("topic", __name__, url_prefix="/")

# 计算热门话题列表
def get_hotTopics():

    topics = TopicModel.query.filter_by(secrecy='0').all()
    my_list = []
    # [(id,浏览量+评论数,对象)]
    for topic in topics:
        my_tuple = (topic.id,len(topic.comments)+len(topic.browse_records),topic)
        my_list.append(my_tuple)
    my_list = sorted(my_list,key=lambda s:s[1],reverse=True)
    hot_topics = []
    for x in my_list:
        hot_topics.append(x[2])
    return hot_topics[:10]

# 进入首页
@bp.route("/")
def index():
    #list类型，拿到所有的topic
    topics = TopicModel.query.filter_by(secrecy='0').order_by(db.text("-create_time")).all()
    hot_topics = get_hotTopics()

    webcount = WebCount.query.first()
    print('当前访问量：',webcount.count)
    WebCount.query.filter_by(id=1).update(
        {'count': webcount.count+1})
    db.session.commit()
    return render_template('index.html', topics=topics[0:5], hot_topics=hot_topics)

# 发表话题
@bp.route("/topic/public", methods=["GET", "POST"])
# 在执行函数前首先进行判断，满足登录条件再执行
@login_required
def public_topic():
    if request.method == 'GET':
        return render_template('public_topic.html')
    else:
        form = TopicForm(request.form)
        if form.validate():
            title = form.title.data
            type = form.type.data
            content = form.content.data
            # 话题默认为公开
            secrecy = 0
            topic = TopicModel(title=title, type=type, content=content, author=g.user, secrecy=secrecy)
            db.session.add(topic)
            db.session.commit()
            print('话题发表成功')

            #调用算法分析话题标题和话题详情，并更新每日心情
            update_emotion(title)
            update_emotion(content)

            return redirect('/')
        else:
            flash("标题或内容格式不正确")
            print("标题或内容格式不正确")
            return redirect(url_for('topic.public_topic'))

# 发表日记
@bp.route("/topic/diary", methods=["GET", "POST"])
# 在执行函数前首先进行判断，满足登录条件再执行
# @login_required
def diary():
    if request.method == 'GET':
        return render_template('diary.html')
    else:
        form = TopicForm(request.form)
        if form.validate():
            title = form.title.data
            type = form.type.data
            content = form.content.data
            # secrecy = form.secrecy.data
            secrecy = 1
            topic = TopicModel(title=title, type=type, content=content, author=g.user, secrecy=secrecy)
            db.session.add(topic)
            db.session.commit()
            return redirect('/')
        else:
            flash("标题或内容格式不正确")
            print("标题或内容格式不正确")
            return redirect(url_for('topic.diary'))

# 打开话题列表
@bp.route("/topic/special/<int:list_type>", methods=["GET", "POST"])
@login_required
def special_topic(list_type):
    hot_topics = get_hotTopics()
    if list_type == 1:
        topics = TopicModel.query.filter_by(type='我的日记',author_id=g.user.id).order_by(db.text("-create_time"))
        topics,pagination = fenye(topics)
        print('进入我的日记')
        return render_template('special_topic.html', pagination=pagination, topics=topics, hot_topics=hot_topics)
    elif list_type == 2:
        topics = TopicModel.query.filter_by(type='老师问卷').order_by(db.text("-create_time"))
        topics,pagination = fenye(topics)
        print('进入老师问卷')
        return render_template('special_topic.html', pagination=pagination, topics=topics, hot_topics=hot_topics)
    else:
        topics = TopicModel.query.filter_by(secrecy='0').order_by(db.text("-create_time"))
        topics,pagination = fenye(topics)
        print('进入全部话题')
        return render_template('special_topic.html', pagination=pagination, topics=topics, hot_topics=hot_topics)

# 存储浏览记录
def record_browse(topic_id):
    print('user_id:',g.user.id)
    print('topic_id:',topic_id)
    browse_record = BrowseRecord(user_id=g.user.id, topic_id=topic_id)
    db.session.add(browse_record)
    db.session.commit()
    return '浏览记录存储成功'

# 打开话题详细页
@bp.route("/topic/<int:topic_id>", methods=["GET", "POST"])
# @login_required
def detail_topic(topic_id):
    user_id = session.get("user_id")
    if user_id:
        record_browse(topic_id)
    topic = TopicModel.query.get(topic_id)
    comment = CommentModel.query.filter_by(topic_id=topic_id).order_by(db.text("-create_time"))
    comments,pagination = fenye(comment)
    hot_topics = get_hotTopics()
    return render_template('detail.html', topic=topic, pagination=pagination, comments=comments, hot_topics=hot_topics)

# 发表评论
@bp.route("/comment/<int:topic_id>", methods=["POST"])
@login_required
def public_comment(topic_id):
    form = CommentForm(request.form)
    if form.validate():
        attitude = form.attitude.data
        comment = form.comment.data
        # 对评论进行情感分析
        result = senta_lstm(comment)
        sentiment = result['sentiment_key']
        emotion = result['negative_probs']
        print("用户发表评论：",g.user.id,topic_id,sentiment)
        comment_model = CommentModel(attitude=attitude,comment=comment,user=g.user,topic_id=topic_id,sentiment=sentiment,emotion=emotion)
        db.session.add(comment_model)
        db.session.commit()
        # 评论存入数据库，重新刷新页面
        # 分析评论数据，更新每日心情
        update_emotion(comment)
        return redirect(url_for("topic.detail_topic",topic_id=topic_id))
    else:
        flash("表单验证失败！")
        return redirect(url_for("topic.detail_topic", topic_id=topic_id))

# 将搜集到的文本数据进行情感分析，并将结果更新到emotion_daily表
def update_emotion(sentence):
    '''
    {   算法返回格式如下：
        'negative_probs': 0.9927,
        'positive_probs': 0.0073,
        'sentiment_key': 'negative',
        'sentiment_label': 0,
        'text': '这饭也太难吃了'
    }
    '''
    result = senta_lstm(sentence)
    negative_probs = result['negative_probs']
    emotion = EmotionDaily.query.filter_by(user_id=g.user.id,date=date.today()).first()
    data_num = emotion.data_num + 1
    emo_sum = emotion.emo_sum + negative_probs
    EmotionDaily.query.filter_by(user_id=g.user.id,date=date.today()).update({'data_num': data_num,'emo_sum': emo_sum})
    db.session.commit()
    print('更新情感数据成功！user_id',g.user.id,negative_probs)

# 搜索！
@bp.route("/search")
@login_required
def search():
    search = request.args.get("search")
    """
    filter:传入模型.字段名（可多个）
    filter_by:直接使用字段名
    此处不能搜出我的日记，需要筛除
    """
    topics = TopicModel.query.filter(or_(TopicModel.title.contains(search),
                                         TopicModel.type.contains(search),
                                         TopicModel.content.contains(search),
                                         UserModel.username.contains(search),
                                         UserModel.sex.contains(search),
                                         UserModel.classroom.contains(search),
                                         ),TopicModel.type!='我的日记'
                                     ).order_by(db.text('-create_time'))
    topics,pagination = fenye(topics)
    return render_template('special_topic.html', pagination=pagination, topics=topics, hot_topics=get_hotTopics())

# 测试分页
@bp.route("/fenye")
def fenye(model):
    # your_model = TopicModel.query.filter_by(secrecy='0').order_by(db.text("-create_time"))
    page = request.args.get(get_page_parameter(), type=int, default=1)
    limit = 5
    start = (page - 1) * limit
    end = start + limit
    res = model.slice(start, end)  # 单页要展示的数据
    pagination = Pagination(page=page, total=model.count(), bs_version=3, per_page=limit)
    return res,pagination
    # return render_template('fenye.html', pagination=pagination, res=res)
