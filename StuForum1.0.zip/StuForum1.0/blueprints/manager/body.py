from datetime import datetime
from flask import Blueprint
from flask import jsonify
from models import BehaviorDaily, UserModel
from utils import db

bp = Blueprint("body",__name__,url_prefix="/body")

# 监控卡片列表数据
@bp.route("/monitorList", methods=["GET"])
def monitorList():
    data = []
    behaviors = BehaviorDaily.query.order_by(db.text("-datetime")).all()
    newBehavior = behaviors[0]
    # 去user表查询应该有多少学生
    classdata = len(UserModel.query.filter_by(classroom=newBehavior.classroom,level=0).all())
    card1 = {
        'title': '应到人数：',
        'data': classdata,
        'other': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }

    card2 = {
        'title': '实到人数：',
        'data': newBehavior.count,
        'other': newBehavior.datetime.strftime('%Y-%m-%d %H:%M:%S')
    }

    dangerCount = 0
    behaviors = BehaviorDaily.query.order_by(db.text("-datetime")).all()
    for behavior in behaviors:
        if behavior.behavior == '未戴口罩':
            dangerCount += behavior.part

    if dangerCount > 5:
        maskData = '较高风险'
    elif dangerCount >=1 and dangerCount <= 5:
        maskData = '较低风险'
    else:
        maskData = '十分安全'
    card3 = {
        'title': '口罩监测：',
        'data': maskData,
        'other': newBehavior.datetime.strftime('%Y-%m-%d %H:%M:%S'),
    }
    card4 = {
        'title': '特殊事件：',
        'data': 0,
        'other': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    data.append(card1)
    data.append(card2)
    data.append(card3)
    data.append(card4)
    return jsonify(data)
# print('monitorList：',monitorList().json)

# 具体事件列表数据
@bp.route("/events", methods=["GET"])
def events():
    data = []
    behaviors = BehaviorDaily.query.order_by(db.text("-datetime")).all()
    print(len(behaviors))
    for behavior in behaviors:
        event1 = {}
        # 只记录最新的四条数据，且是危险数据
        if behavior.behavior != '安全正常' and len(data) < 4:
            event1['img'] = behavior.imgPath
            event1['title'] = behavior.behavior
            event1['classroom'] = behavior.classroom
            event1['datetime'] = behavior.datetime.strftime('%Y-%m-%d %H:%M:%S')
            data.append(event1)
    return jsonify(data)
# print('events：',events().json)