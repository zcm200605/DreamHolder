from models import UserModel, EmotionDaily, CommentModel, WebCount, TopicModel, BrowseRecord
from flask import jsonify,Blueprint
from datetime import date
import datetime

bp = Blueprint("forum",__name__,url_prefix="/forum")

# 时间有关的公共方法
def all_timelist():
    alldate = EmotionDaily.query.all()
    datelist = []
    for x in alldate:
        if x.date not in datelist:
            datelist.append(x.date)
    return datelist

# 左上角两个卡片（历史和日均）
@bp.route("/forumCard", methods=["GET", "POST"])
def forumCard():
    result = {}
    datacounts = 0
    timedalta = ((date.today()-datetime.date(2022, 4, 14))).days
    allwebc = WebCount.query.all()[0].count
    allbrow = len(BrowseRecord.query.all())
    for emo in EmotionDaily.query.all():
        datacounts += emo.data_num
    dailybrowsec = len(BrowseRecord.query.all())/timedalta
    dailycomment = len(CommentModel.query.all())/timedalta
    dailyTopic = len(TopicModel.query.all())/timedalta
    result['webCount'] = allwebc
    result['browseCount'] = allbrow
    result['dataCount'] = datacounts
    result['dailyBrowse'] = int(dailybrowsec)
    result['dailyComment'] = int(dailycomment)
    result['dailyTopic'] = int(dailyTopic)
    return jsonify(result)
# print(forumCard().json)

# 右上角历史数据列表
@bp.route("/hotCard", methods=["GET", "POST"])
def hotCard():
    result = {}
    historyData = []
    for times in all_timelist():
        flag = {}
        day_hotcount = 0
        for com in CommentModel.query.all():
            if com.create_time == times:
                day_hotcount += 1
        for top in TopicModel.query.all():
            if top.create_time == times:
                day_hotcount += 1
        flag['x'] = times.strftime('%Y-%m-%d')
        flag['y'] = day_hotcount
        historyData.append(flag)
    trend = ''
    if historyData[0]['y'] - historyData[-1]['y'] < 0:
        trend += '总升'
    elif historyData[0]['y'] - historyData[-1]['y'] == 0:
        trend += '总稳'
    else:
        trend += '总降'
    if historyData[-2]['y'] - historyData[-1]['y'] < 0:
        trend += ',近升'
    elif historyData[-2]['y'] - historyData[-1]['y'] == 0:
        trend += ',近稳'
    else:
        trend += ',近降'
    result['historyData'] = historyData
    result['trend'] = trend
    return jsonify(result)
# print(hotCard().json)

# 全部话题列表
@bp.route("/allTopic", methods=["GET", "POST"])
def allTopic():
    result = []
    for top in TopicModel.query.all():
        flag = {}
        flag['topicId'] = top.id
        flag['title'] = top.title
        flag['type'] = top.type
        flag['content'] = top.content
        flag['date'] = top.create_time.strftime('%Y-%m-%d')
        flag['author'] = UserModel.query.filter_by(id=top.author_id).all()[0].username
        result.append(flag)
    return jsonify(result)
# print(allTopic().json)

# 话题类型饼图
@bp.route("/pieSourceData", methods=["GET", "POST"])
def pieSourceData():
    result = []
    richang, riji, wenjuan, fenxiang, qiuzhu, guanxi = 0, 0, 0, 0, 0, 0
    flag1, flag2, flag3, flag4, flag5, flag6 = {}, {}, {}, {}, {}, {}
    for top in TopicModel.query.all():
        if top.type == '日常生活':
            richang += 1
        elif top.type == '我的日记':
            riji += 1
        elif top.type == '老师问卷':
            wenjuan += 1
        elif top.type == '心情分享':
            fenxiang += 1
        elif top.type == '问题求助':
            qiuzhu += 1
        else:
            guanxi += 1
    flag1['item'] = '日常生活'
    flag2['item'] = '我的日记'
    flag3['item'] = '老师问卷'
    flag4['item'] = '心情分享'
    flag5['item'] = '问题求助'
    flag6['item'] = '师生关系'
    flag1['count'] = richang
    flag2['count'] = riji
    flag3['count'] = wenjuan
    flag4['count'] = fenxiang
    flag5['count'] = qiuzhu
    flag6['count'] = guanxi
    flag1['percent'] = richang / (richang + riji + wenjuan + fenxiang + qiuzhu + guanxi)
    flag2['percent'] = riji / (richang + riji + wenjuan + fenxiang + qiuzhu + guanxi)
    flag3['percent'] = wenjuan / (richang + riji + wenjuan + fenxiang + qiuzhu + guanxi)
    flag4['percent'] = fenxiang / (richang + riji + wenjuan + fenxiang + qiuzhu + guanxi)
    flag5['percent'] = qiuzhu / (richang + riji + wenjuan + fenxiang + qiuzhu + guanxi)
    flag6['percent'] = guanxi / (richang + riji + wenjuan + fenxiang + qiuzhu + guanxi)
    result.append(flag1)
    result.append(flag2)
    result.append(flag3)
    result.append(flag4)
    result.append(flag5)
    result.append(flag6)
    return jsonify(result)
# print(pieSourceData().json)

# 右下角极端评论检测——消极评论列表
@bp.route("/dangerlist", methods=["GET", "POST"])
def dangerlist():
    result = []
    stuid = UserModel.query.all()
    emocom = CommentModel.query.all()
    for stu in stuid:
        if stu.level != 1:
            for emo in emocom:
                emos = {}
                if stu.id == emo.user_id and emo.emotion > 0.995:
                    emos['index'] = stu.id
                    emos['name'] = stu.username
                    emos['comment'] = emo.comment
                    emos['emotion'] = int(emo.emotion * 100)
                    result.append(emos)
    return jsonify(result)
# print('dangerlist：',dangerlist().json)

# 话题历史数据趋势图
@bp.route("/topicData", methods=["GET", "POST"])
def topicData():
    finaresult, flag1, flag2 = {}, {}, {}
    result1, result2, timalist = [], [], []
    for times in all_timelist():
        flag = {}
        day_hotcount = 0
        for top in TopicModel.query.all():
            if top.create_time == times:
                day_hotcount += 1
        flag['x'] = times.strftime('%Y-%m-%d')
        flag['y'] = day_hotcount
        timalist.append(day_hotcount)
        result1.append(flag)
    flag1['dataKey'] = 'x'
    flag1['alias'] = '时间'
    flag2['dataKey'] = 'y'
    flag2['alias'] = '话题数'
    flag2['min'] = '0'
    flag2['max'] = '15'
    result2.append(flag1)
    result2.append(flag2)
    topicTotal = len(TopicModel.query.all())
    trend = ''
    if timalist[0] - timalist[-1] < 0:
        trend += '总体升'
    elif timalist[0] - timalist[-1] == 0:
        trend += '总稳定'
    else:
        trend += '总体降'

    if timalist[-2] - timalist[-1] < 0:
        trend += ',近期升'
    elif timalist[-2] - timalist[-1] == 0:
        trend += ',近期稳'
    else:
        trend += ',近期降'
    finaresult['topicDaily'] = result1
    finaresult['topicScale'] = result2
    finaresult['topicTotal'] = topicTotal
    finaresult['topicTrend'] = trend
    return jsonify(finaresult)
# print(topicData().json)

# 评论历史数据趋势图
@bp.route("/commentData", methods=["GET", "POST"])
def commentData():
    finaresult, flag1, flag2 = {}, {}, {}
    result1, result2, timalist = [], [], []
    for times in all_timelist():
        flag = {}
        day_hotcount = 0
        for com in CommentModel.query.all():
            if com.create_time == times:
                day_hotcount += 1
        flag['x'] = times.strftime('%Y-%m-%d')
        flag['y'] = day_hotcount
        timalist.append(day_hotcount)
        result1.append(flag)
    flag1['dataKey'] = 'x'
    flag1['alias'] = '时间'
    flag2['dataKey'] = 'y'
    flag2['alias'] = '话题数'
    flag2['min'] = '0'
    flag2['max'] = '60'
    result2.append(flag1)
    result2.append(flag2)
    commentTotal = len(CommentModel.query.all())
    trend = ''
    if timalist[0] - timalist[-1] < 0:
        trend += '总体升'
    elif timalist[0] - timalist[-1] == 0:
        trend += '总体稳'
    else:
        trend += '总体降'
    if timalist[-2] - timalist[-1] < 0:
        trend += ',近期升'
    elif timalist[-2] - timalist[-1] == 0:
        trend += ',近期稳'
    else:
        trend += ',近期降'

    finaresult['commentDaily'] = result1
    finaresult['commentScale'] = result2
    finaresult['commentTotal'] = commentTotal
    finaresult['commentTrend'] = trend
    return jsonify(finaresult)
# print(commentData().json)