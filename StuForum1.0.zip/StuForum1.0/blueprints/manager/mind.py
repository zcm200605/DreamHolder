from flask import Blueprint
from models import UserModel, EmotionDaily, CommentModel, WebCount
from utils import db
from sqlalchemy import func
from flask import jsonify
from datetime import date

bp = Blueprint("mind",__name__,url_prefix="/mind")

# 时间有关的公共方法
def all_timelist():
    alldate = EmotionDaily.query.all()
    datelist = []
    for x in alldate:
        if x.date not in datelist:
            datelist.append(x.date)
    return datelist
# 计算班级多少人
def all_classStudent(classroom):
    counts = db.session.query(func.count(UserModel.classroom)).filter(
        UserModel.classroom == classroom,
        UserModel.level != 1
    ).scalar()
    return counts
# 计算一共多少人
def all_stu():
    counts = db.session.query(func.count(UserModel.id)).filter(
        UserModel.level == '0').scalar()
    return counts

# 全部学生卡片card
@bp.route("/allStudentCard", methods=["GET", "POST"])
def allStudentCard():
    data = {}
    negativeStu = []
    stuid = UserModel.query.all()
    for date in all_timelist():
        days = EmotionDaily.query.filter_by(date=date).all()
        for day in days:
            if day.emo_sum != 0:
                level = day.emo_sum / day.data_num
                for stu in stuid:
                    if level >= 0.7 and day.user_id == stu.id:
                        if stu.username not in negativeStu:
                            negativeStu.append(stu.username)
    data['allStu'] = all_stu()
    data['negativeStu'] = len(negativeStu)
    data['negativePercentage'] = int(len(negativeStu)/len(stuid) * 100)
    print(data)
    return(jsonify(data))
# print('allStudentCard：',allStudentCard().json)

# 各个班级数据卡片card
@bp.route("/classCard", methods=["GET", "POST"])
def classCard():
    data = {}
    oneClass = []
    twoClass = []
    threeClass = []
    stuid = UserModel.query.all()
    for date in all_timelist():
        days = EmotionDaily.query.filter_by(date=date).all()
        for day in days:
            if day.emo_sum != 0:
                level = day.emo_sum / day.data_num
                for stu in stuid:
                    if level >= 0.7 and day.user_id == stu.id:
                        if stu.classroom == '高一一班' and stu.username not in oneClass:
                            oneClass.append(stu.username)
                        if stu.classroom == '高一二班' and stu.username not in twoClass:
                            twoClass.append(stu.username)
                        if stu.classroom == '高一三班' and stu.username not in threeClass:
                            threeClass.append(stu.username)
    data['oneClass'] = len(oneClass)
    data['twoClass'] = len(twoClass)
    data['threeClass'] = len(threeClass)
    data['date'] = date.today().strftime('%Y-%m-%d')
    print(data)
    return (jsonify(data))
# print('classCard：',classCard().json)

# 人均消极占比卡片card
@bp.route("/negativeCard", methods=["GET", "POST"])
def negativeCard():
    data = {}
    alldate = EmotionDaily.query.all()
    emo, num = 0, 0
    for days in alldate:
        emo += days.emo_sum
        num += days.data_num
    data['negativePercentage'] = int(emo/num * 100)
    data['date'] = date.today().strftime('%Y-%m-%d')
    print(data)
    return jsonify(data)
# print('negativeCard：',negativeCard().json)

# 历史消极占比卡片 historyData
@bp.route("/historyData", methods=["GET", "POST"])
def historyData():
    result = []
    for date in all_timelist():
        emo, num = 0, 0
        historyData = {}
        days = EmotionDaily.query.filter_by(date=date).all()
        for day in days:
            emo += day.emo_sum
            num += day.data_num
        historyData['x'] = date.strftime('%Y-%m-%d')
        if num == 0:
            historyData['y'] = 0
        else:
            historyData['y'] = emo/num
        result.append(historyData)
    print(result)
    return jsonify(result)
# print('historyData：',historyData().json)

# 历史消极占比卡片 historyCard
@bp.route("/historyCard", methods=["GET", "POST"])
def historyCard():
    data = {}
    result = []
    trend = ''
    for date in all_timelist():
        emo, num = 0, 0
        days = EmotionDaily.query.filter_by(date=date).all()
        for day in days:
            emo += day.emo_sum
            num += day.data_num
        if num == 0:
            result.append(0)
        else:
            result.append(emo/num)
    if result[0]-result[-1] < 0:
        trend += '总升'
    elif result[0]-result[-1] == 0:
        trend += '总稳'
    else:
        trend += '总降'

    if result[-2] - result[-1] < 0:
        trend += ',近升'
    elif result[-2] - result[-1] == 0:
        trend += ',近稳'
    else:
        trend += ',近降'
    data['date'] = date.today().strftime('%Y-%m-%d')
    data['trend'] = trend
    print(data)
    return jsonify(data)
# print('historyCard：',historyCard().json)

# 心理健康报告——消极学生列表
@bp.route("/dangerList", methods=["GET", "POST"])
def dangerList():
    result = []
    stuid = UserModel.query.all()
    emostu = EmotionDaily.query.all()
    for stu in stuid:
        emo_count, for_count = 0, 0
        if stu.level != 1:
            for emo in emostu:
                if stu.id == emo.user_id and emo.data_num != 0:
                    emo_count += emo.emo_sum/emo.data_num
                    for_count += 1
            emos = {}
            emos['userid'] = stu.id
            emos['name'] = stu.username
            emos['classroom'] = stu.classroom
            if for_count == 0:
                emos['emotion'] = 0
            else:
                percentage = int(emo_count / for_count * 100)
                emos['emotion'] = percentage
            if emos['emotion'] > 70:
                emos['status'] = '极端消极'
                result.append(emos)
    return jsonify(result)
# print('dangerList：',dangerList().json)

# 中间部分——班级日均消极心态占比图：
@bp.route("/barData/<int:num>", methods=["GET", "POST"])
def barData(num):
    if num == 1:
        classroom = '高一一班'
    elif num == 2:
        classroom = '高一二班'
    else:
        classroom = '高一三班'
    result = []
    stuid = UserModel.query.all()
    for date in all_timelist():
        sum, emo, num = 0, 0, 0
        days = EmotionDaily.query.filter_by(date=date).all()
        tmp = []
        flag = {}
        for day in days:
            for stu in stuid:
                if day.user_id == stu.id and stu.classroom == classroom and day.data_num != 0 and stu.level != 1:
                    emo += day.emo_sum
                    num += day.data_num
                    tmp.append(emo/num)
                    sum += emo / num
        # print(date)
        flag['x'] = date.strftime('%m-%d')
        if len(tmp) != 0:
            flag['y'] = sum/len(tmp)
        else:
            flag['y'] = 0.0
        result.append(flag)
    return jsonify(result)
# print(barData(1).json)

# 中间部分——消极学生top7列表
@bp.route("/rankList/<int:num>", methods=["GET", "POST"])
def rankList(num):
    if num == 1:
        classroom = '高一一班'
    elif num == 2:
        classroom = '高一二班'
    else:
        classroom = '高一三班'
    result = []
    stuid = UserModel.query.all()
    emostu = EmotionDaily.query.all()
    for stu in stuid:
        emo_count, for_count = 0, 0
        if stu.level != 1 and stu.classroom == classroom:
            for emo in emostu:
                if stu.id == emo.user_id and emo.data_num != 0:
                    emo_count += emo.emo_sum / emo.data_num
                    for_count += 1
            emos = {}
            emos['name'] = stu.username
            if for_count == 0:
                emos['total'] = 0
            else:
                percentage = int(emo_count / for_count * 100)
                emos['total'] = percentage
            result.append(emos)
    result.sort(key=lambda x:-x['total'])
    return jsonify(result[:7])
# print('rankList：',rankList(1).json)

# 左下角额外趋势图——每日消极人数
@bp.route("/daily_emo", methods=["GET", "POST"])
def daily_emo():
    result = []
    for date in all_timelist():
        flag = {}
        neg_count = 0
        days = EmotionDaily.query.filter_by(date=date).all()
        for day in days:

            if day.emo_sum != 0:
                level = day.emo_sum/day.data_num
                if level >= 0.7:
                    neg_count += 1
                flag['date'] = date.strftime('%Y-%m-%d')
                flag['count'] = neg_count
        result.append(flag)
    return jsonify(result)
# print('daily_emo：',daily_emo().json)

# 左下角额外趋势图——每日积极人数
@bp.route("/daily_pos", methods=["GET", "POST"])
def daily_pos():
    result = []
    for date in all_timelist():
        flag = {}
        pos_count = 0
        days = EmotionDaily.query.filter_by(date=date).all()
        for day in days:
            if day.emo_sum != 0:
                level = day.emo_sum/day.data_num
                if level < 0.3:
                    pos_count += 1
            else:
                pos_count += 1
            flag['date'] = date.strftime('%Y-%m-%d')
            flag['count'] = pos_count
        result.append(flag)
    return jsonify(result)
# print('daily_pos：',daily_pos().json)

@bp.route("/allStudent", methods=["GET", "POST"])
def allStudent():
    result = []
    stuid = UserModel.query.all()
    emostu = EmotionDaily.query.all()
    for stu in stuid:
        emo_count, for_count = 0, 0
        if stu.level != 1:
            for emo in emostu:
                if stu.id == emo.user_id and emo.data_num != 0:
                    emo_count += (emo.emo_sum / emo.data_num)
                    for_count += 1
            emos = {}
            emos['userid'] = stu.id
            emos['username'] = stu.username
            emos['sex'] = stu.sex
            emos['classroom'] = stu.classroom
            if for_count != 0:
                emos['negative'] = int((emo_count / for_count) * 100)
                emos['positive'] = 100-int((emo_count / for_count) * 100)
            else:
                emos['negative'] = 0
                emos['positive'] = 100
            result.append(emos)
    return jsonify(result)
# print(allStudent().json)

@bp.route("/pieSourceData", methods=["GET", "POST"])
def pieSourceData():
    result = []
    emos1,emos2,emos3,emos4,emos5 = {},{},{},{},{}
    stuid = UserModel.query.all()
    emostu = EmotionDaily.query.all()
    a,b,c,d,e = 0, 0, 0, 0, 0
    for stu in stuid:
        emo_count, for_count = 0, 0
        if stu.level != 1:
            for emo in emostu:
                if stu.id == emo.user_id and emo.data_num != 0:
                    emo_count += emo.emo_sum / emo.data_num
                    for_count += 1
        if for_count != 0:
            if 0 <= emo_count / for_count < 0.2:
                a += 1
            elif 0.2 <= emo_count / for_count < 0.4:
                b += 1
            elif 0.4 <= emo_count / for_count < 0.6:
                c += 1
            elif 0.6 <= emo_count / for_count < 0.75:
                d += 1
            else:
                e += 1
        else:
            a += 1
    emos1['item'] = '非常积极'
    emos2['item'] = '正常积极'
    emos3['item'] = '无喜无悲'
    emos4['item'] = '比较消极'
    emos5['item'] = '非常消极'

    emos1['count'] = a
    emos2['count'] = b
    emos3['count'] = c
    emos4['count'] = d
    emos5['count'] = e

    emos1['percent'] = a / (a + b + c + d + e)
    emos2['percent'] = b / (a + b + c + d + e)
    emos3['percent'] = c / (a + b + c + d + e)
    emos4['percent'] = d / (a + b + c + d + e)
    emos5['percent'] = e / (a + b + c + d + e)

    result.append(emos1)
    result.append(emos2)
    result.append(emos3)
    result.append(emos4)
    result.append(emos5)
    return jsonify(result)
# print(pieSourceData().json)