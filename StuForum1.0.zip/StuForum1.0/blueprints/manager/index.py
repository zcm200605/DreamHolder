from flask import Blueprint
from flask import jsonify
from datetime import date,datetime
from models import EmotionDaily,UserModel,CommentModel,WebCount,BehaviorDaily
from utils import db

bp = Blueprint("index",__name__,url_prefix="/index")

# 总体心理健康评估card，人均消极占比卡片
@bp.route('/mindCard', methods=['GET'])
def mindCard():
    data = {}
    alldate = EmotionDaily.query.all()
    emo, num = 0, 0
    for days in alldate:
        emo += days.emo_sum
        num += days.data_num
    percentage = int(emo/num * 100)
    data['negativePercentage'] = percentage
    data['date'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(data)
    return jsonify(data)

# 校园论坛状态评估card
@bp.route('/forumCard', methods=['GET'])
def forumCard():
    data = {}
    comments = CommentModel.query.all()
    negativeComment = 0
    for comm in comments:
        if comm.emotion > 0.995:
            negativeComment += 1
            print(comm.comment)
    webCount = WebCount.query.all()[0].count
    specialTopic = 0
    if specialTopic + negativeComment > 30:
        totalForumStatus = '高风险，需管理'
    elif specialTopic + negativeComment >=10 and specialTopic + negativeComment < 30:
        totalForumStatus = '中风险，可管理'
    else:
        totalForumStatus = '健康运行中'
    data['totalForumStatus'] = totalForumStatus
    # 特殊话题检测等待写！！！
    data['specialTopic'] = specialTopic
    data['negativeComment'] = negativeComment
    data['webCount'] = webCount
    return jsonify(data)

# 身体健康状态card
@bp.route('/bodyCard', methods=['GET'])
def bodyCard():
    data = {}
    dangerCount = 0
    behaviors = BehaviorDaily.query.order_by(db.text("-datetime")).all()
    for behavior in behaviors[:10]:
        if behavior.behavior == '未戴口罩':
            dangerCount += behavior.part

    if dangerCount > 5:
        maskData = '较高风险'
    elif dangerCount >=1 and dangerCount <= 5:
        maskData = '中等风险'
    else:
        maskData = '十分安全'
    newBehavior = behaviors[0]
    classStu = newBehavior.count
    data['dangerCount'] = dangerCount
    data['classStu'] = classStu
    data['maskData'] = maskData
    return jsonify(data)
# print('bodyCard:',bodyCard().json)

# 身体健康报告——危险行为列表
@bp.route('/bodyData', methods=['GET'])
def bodyData():
    data = []
    # x = {}
    behaviors = BehaviorDaily.query.order_by(db.text("-datetime")).all()
    for behavior in behaviors:
        x = {}
        if behavior.behavior != '安全正常':
            x['index'] = behavior.id
            x['classroom'] = behavior.classroom
            x['datetime'] = behavior.datetime.strftime('%Y-%m-%d %H:%M:%S')
            x['danger'] = behavior.behavior
            data.append(x)
    return jsonify(data)
# print('bodyData:',bodyData().json)

# 心理健康报告——消极学生列表
@bp.route('/mindData', methods=['GET'])
def mindData():
    result = []
    stuid = UserModel.query.all()
    emostu = EmotionDaily.query.all()
    for stu in stuid:
        emo_count, for_count = 0, 0
        if stu.level != 1:
            for emo in emostu:
                if stu.id == emo.user_id and emo.data_num != 0:
                    emo_count += emo.emo_sum/emo.data_num
                    for_count += 1
            emos = {}
            emos['index'] = stu.id
            emos['name'] = stu.username
            emos['classroom'] = stu.classroom
            if for_count == 0:
                emos['emotion'] = 0
            else:
                percentage = int(emo_count / for_count * 100)
                emos['emotion'] = percentage
            if emos['emotion'] > 70:
                result.append(emos)
    return jsonify(result)

# 学校论坛报告——极端评论列表
@bp.route('/forumData', methods=['GET'])
def forumData():
    result = []
    stuid = UserModel.query.all()
    emocom = CommentModel.query.all()
    for stu in stuid:
        if stu.level != 1:
            for emo in emocom:
                emos = {}
                if stu.id == emo.user_id and emo.emotion > 0.995:
                    emos['index'] = stu.id
                    emos['name'] = stu.username
                    emos['comment'] = emo.comment
                    emos['emotion'] = int(emo.emotion * 100)
                    result.append(emos)
    return jsonify(result)
# print('forumData：',forumData().json)




