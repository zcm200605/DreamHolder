import jieba
from flask import Blueprint
from models import UserModel, EmotionDaily, CommentModel, TopicModel
from flask import jsonify
from datetime import date
import numpy as np

bp = Blueprint("specific",__name__,url_prefix="/specific")

# 时间有关的公共方法
def all_timelist():
    alldate = EmotionDaily.query.all()
    datelist = []
    for x in alldate:
        if x.date not in datelist:
            datelist.append(x.date)
    return datelist

# 左下角历史数据列表
@bp.route('/historyData/<int:id>', methods=['GET'])
def historyData(id):
    result = []
    stuid = UserModel.query.filter_by(id=id).all()[0].id
    for date in all_timelist():
        flag = {}
        days = EmotionDaily.query.filter_by(date=date).all()
        for day in days:
            if day.emo_sum != 0 and day.user_id == stuid:
                level = (day.emo_sum / day.data_num)
                flag['x'] = date.strftime('%Y-%m-%d')
                flag['y'] = level
            elif day.emo_sum == 0 and day.user_id == stuid:
                flag['x'] = date.strftime('%Y-%m-%d')
                flag['y'] = 0
        if len(flag) != 0:
            result.append(flag)
    return jsonify(result)
# print('historyData：',historyData(11).json)

# 左下角历史数据趋势
@bp.route('/historyCard/<int:id>', methods=['GET'])
def historyCard(id):
    data = {}
    result = []
    stuid = UserModel.query.filter_by(id=id).all()[0].id
    for date in all_timelist():
        days = EmotionDaily.query.filter_by(date=date).all()
        for day in days:
            if day.emo_sum != 0 and day.user_id == stuid:
                level = (day.emo_sum / day.data_num)
                result.append(level)
            elif day.emo_sum == 0 and day.user_id == stuid:
                result.append(0)
    trend = ''
    if len(result) != 0:
        if result[0] - result[-1] < 0:
            trend += '总升'
        elif result[0] - result[-1] == 0:
            trend += '总稳'
        else:
            trend += '总降'

        if result[-2] - result[-1] < 0:
            trend += ',近升'
        elif result[-2] - result[-1] == 0:
            trend += ',近稳'
        else:
            trend += ',近降'
    else:
        trend = '暂无数据'
    data['date'] = date.today().strftime('%Y-%m-%d')
    data['trend'] = trend
    return jsonify(data)
# print('historyCard：',historyCard(11).json)

# 学生基本信息card
@bp.route('/stuCard/<int:id>', methods=['GET'])
def stuCard(id):
    result = {}
    stuid = UserModel.query.filter_by(id=id).all()[0]
    result['username'] = stuid.username
    result['classroom'] = stuid.classroom
    result['sex'] = stuid.sex
    result['email'] = stuid.email
    result['browse'] = len(stuid.browse_records)
    result['height'] = stuid.height
    result['weight'] = stuid.weight
    result['comment'] = len(CommentModel.query.filter_by(user_id=id).all())
    result['topic'] = len(TopicModel.query.filter_by(author_id=id).all())

    historyData = []
    for date in all_timelist():
        days = EmotionDaily.query.filter_by(date=date).all()
        for day in days:
            if day.emo_sum != 0 and day.user_id == id:
                level = day.emo_sum / day.data_num
                historyData.append(level)
            elif day.emo_sum == 0 and day.user_id == id:
                historyData.append(0)
    # 求方差
    varData = np.var(historyData)
    if 0< varData <= 0.05:
        result['character'] = '比较稳定'
    elif 0.05< varData <= 0.1:
        result['character'] = '轻微波动'
    elif 0.1< varData <= 0.2:
        result['character'] = '较大波动'
    else:
        result['character'] = '巨大波动'

    # 计算是否超重
    if stuid.weight/(stuid.height/100 * stuid.height/100) < 18.5:
        result['BMI'] = '体重过轻'
    elif 18.5 <= stuid.weight/(stuid.height/100 * stuid.height/100) < 25:
        result['BMI'] = '体重正常'
    elif 25 <= stuid.weight/(stuid.height/100 * stuid.height/100) < 30:
        result['BMI'] = '超重'
    elif 30 <= stuid.weight/(stuid.height/100 * stuid.height/100):
        result['BMI'] = '肥胖'

    # 计算单个学生的平均emotion
    emosum, datesum = 0, 0
    stuid = EmotionDaily.query.filter_by(user_id=id).all()
    for stu in stuid:
        emosum += stu.emo_sum
        datesum += stu.data_num
    level = 1 - emosum/datesum

    if 0 <= level < 0.2:
        result['emotion'] = '非常消极'
    elif 0.2 <= level < 0.4:
        result['emotion'] = '比较消极'
    elif 0.4 <= level < 0.6:
        result['emotion'] = '无喜无悲'
    elif 0.6 <= level < 0.8:
        result['emotion'] = '正常积极'
    else:
        result['emotion'] = '非常积极'

    return jsonify(result)
# print(stuCard(11).json)

# 词云数据
@bp.route('/wordcloud/<int:id>', methods=['GET'])
def wordcloud(id):
    result = []
    all_list = []
    counts = {}
    for com in CommentModel.query.filter_by(user_id=id).all():
        all_list.append(str(com.comment))
    for top in TopicModel.query.filter_by(author_id=id).all():
        all_list.append(str(top.title))
        all_list.append(str(top.content))
    for indi in all_list:
        ls = jieba.lcut(indi, cut_all=False)
        for word in ls:
            counts[word] = counts.get(word, 0) + 1
    for it in counts.items():
        x = {}
        if it[1] != 1 and len(it[0]) != 1:
            x['x'] = it[0]
            x['value'] = it[1]
            result.append(x)
    print(len(result))
    return jsonify(result)
# print(wordcloud().json)

# 左下角近日积极占比卡片
@bp.route('/positiveCard/<int:id>', methods=['GET'])
def positiveCard(id):
    result = {}
    emosum, datesum = 0, 0
    stuid = EmotionDaily.query.filter_by(user_id=id).all()
    for stu in stuid:
        emosum += stu.emo_sum
        datesum += stu.data_num
    level = emosum/datesum
    result['positivePercentage'] = int((1 - level)*100)
    result['date'] = date.today().strftime('%Y-%m-%d')
    return jsonify(result)
# print(historyCard(11).json)

# 系统评语
@bp.route('/analysis/<int:id>', methods=['GET'])
def analysis(id):
    '''
    性格分析：
        1、性别
        2、历史情绪方差
        3、平均情绪
        4、日记数据之比
        5、评论数与话题之比
        6、浏览记录与话题、评论数之比
    '''
    result = []
    student = UserModel.query.filter_by(id=id).all()[0]

    historyData = []
    for date in all_timelist():
        days = EmotionDaily.query.filter_by(date=date).all()
        for day in days:
            if day.emo_sum != 0 and day.user_id == id:
                level = day.emo_sum / day.data_num
                historyData.append(level)
            elif day.emo_sum == 0 and day.user_id == id:
                historyData.append(0)
    # 求方差
    varData = np.var(historyData)
    if 0< varData <= 0.05:
        result.append('学生情绪稳定性较高，无需特别关注')
    elif 0.05< varData <= 0.1:
        result.append('学生情绪有轻微波动，可适当关注')
    elif 0.1< varData <= 0.2:
        result.append('学生情绪有较大波动，请特别关注')
    else:
        result.append('学生情绪有巨大波动，建议交流指导')
    # 消极情绪的均值
    meanData = np.mean(historyData)
    if 0 < meanData <= 0.4:
        result.append('学生总体情绪积极，请继续保持')
    elif 0.4 < meanData <= 0.6:
        result.append('学生总体情绪正常，请继续保持')
    elif 0.6 < meanData <= 0.80:
        result.append('学生总体情绪消极，建议给予适当鼓励')
    else:
        result.append('学生总体情绪非常消极，建议交流指导')
    topicsData = student.topics
    diary = 0
    for x in topicsData:
        if x.type == '我的日记':
            diary += 1
    sex = student.sex
    topic = len(student.topics) - diary
    comment = len(student.comments)
    browse_records = len(student.browse_records)
    diaryFlag = (diary/(topic+diary))*100
    if sex=='女':
        if diaryFlag >=40 :
            result.append('学生为内倾型女生，交流时请保持耐心')
            result.append('学生心思细腻敏感，适当注意语气、措辞')
        else:
            result.append('学生无明显内倾型特征，交流时可适当放开')
        if browse_records < 4*(topic+comment):
            result.append('学生有主动倾诉、表达的意向，可注意倾听')
        else:
            result.append('学生无强烈的主动倾诉意向，可适当引导沟通')
    else:
        # 男生
        if diaryFlag >=20 :
            result.append('学生为内倾型男生，交流时请保持耐心')
        else:
            result.append('学生无明显内倾型特征，交流时可适当放开')
        if browse_records < 3*(topic+comment):
            result.append('学生有主动倾诉、表达的意向，可注意倾听')
        else:
            result.append('学生无强烈的主动倾诉意向，可适当引导沟通')

    return jsonify(result)
# print(analysis(11).json)


# 缺少数据，雷达图
@bp.route('/radarData/<int:id>', methods=['GET'])
def radarData(id):
    result = []
    zhangemo, zhangdate = 0, 0
    allemo, alldate, sumstu= 0, 0, 0
    stus = UserModel.query.filter_by(id=id).all()[0]
    emos = EmotionDaily.query.filter_by(user_id=id).all()
    stuids = UserModel.query.all()
    stucounts = len(stuids)
    emostus = EmotionDaily.query.all()
    for emo in emos:
        zhangemo += emo.emo_sum
        zhangdate += emo.data_num
    zhanglevel = zhangemo/zhangdate
    for emost in emostus:
        allemo += emost.emo_sum
        alldate += emost.data_num
    alllevel = allemo / alldate

    # 计算积极比例
    neg1,neg2 = {},{}
    neg1['item'] = '消极比例'
    neg1['user'] = stus.username
    neg1['score'] = int(zhanglevel/alllevel * 100)

    neg2['item'] = '消极比例'
    neg2['user'] = '平均值'
    neg2['score'] = 95
    result.append(neg1)
    result.append(neg2)

    # 计算消极比例
    pos1,pos2 = {},{}
    pos1['item'] = '积极比例'
    pos1['user'] = stus.username
    pos1['score'] = int((1-zhanglevel)/(1-alllevel) * 100)

    pos2['item'] = '积极比例'
    pos2['user'] = '平均值'
    pos2['score'] = 90
    result.append(pos1)
    result.append(pos2)

    # 计算健康指数
    for stu in stuids:
        level = stu.weight/(stu.height/100 * stu.height/100)
        sumstu += level
    allbody = sumstu/stucounts
    zhangbody = stus.weight/(stus.height/100 * stus.height/100)


    body1,body2 = {},{}
    body1['item'] = '健康指数'
    body1['user'] = stus.username
    body1['score'] = int(zhangbody/allbody * 100)

    body2['item'] = '健康指数'
    body2['user'] = '平均值'
    body2['score'] = 70

    result.append(body1)
    result.append(body2)

    # 主动倾诉、内倾特征
    zhudong1,zhudong2 = {},{}
    neixiang1,neixiang2 = {},{}
    bodong1,bodong2 = {},{}
    historyData = []
    for date in all_timelist():
        days = EmotionDaily.query.filter_by(date=date).all()
        for day in days:
            if day.emo_sum != 0 and day.user_id == id:
                level = day.emo_sum / day.data_num
                historyData.append(level)
            elif day.emo_sum == 0 and day.user_id == id:
                historyData.append(0)
    # 求方差
    varData = np.var(historyData)

    topicsData = stus.topics
    diary = 0
    for x in topicsData:
        if x.type == '我的日记':
            diary += 1
    topic = len(stus.topics) - diary
    comment = len(stus.comments)
    browse_records = len(stus.browse_records)

    zhudong1['item'] = '主动倾诉'
    zhudong1['user'] = stus.username
    zhudong1['score'] = int(((topic+comment)*3)/browse_records * 100) - 20

    zhudong2['item'] = '主动倾诉'
    zhudong2['user'] = '平均值'
    zhudong2['score'] = 80

    neixiang1['item'] = '内倾指数'
    neixiang1['user'] = stus.username
    neixiang1['score'] = int((diary/(diary+topic))*100)

    neixiang2['item'] = '内倾指数'
    neixiang2['user'] = '平均值'
    neixiang2['score'] = 20

    bodong1['item'] = '稳定指数'
    bodong1['user'] = stus.username
    bodong1['score'] = int((1-varData)*100)

    bodong2['item'] = '稳定指数'
    bodong2['user'] = '平均值'
    bodong2['score'] = 90

    result.append(zhudong1)
    result.append(zhudong2)
    result.append(neixiang1)
    result.append(neixiang2)
    result.append(bodong1)
    result.append(bodong2)


    return jsonify(result)
# print(radarData(11).json)