from models import BehaviorDaily
from utils import db
import os
import cv2
import paddlehub as hub

def getNowImg():
    # cap = cv2.VideoCapture('http://admin:admin@192.168.3.148:8554')
    cap = cv2.VideoCapture(0)
    ret, frame = cap.read()
    # 缩放并利用INTER_CUBIC插值法
    frame = cv2.resize(frame, (640, 480), interpolation=cv2.INTER_CUBIC)

    filename = 'D:\StuForum1.0\img\camera\\now.jpg'
    flag = os.path.isfile(filename)
    if flag:
        os.remove('D:\StuForum1.0\img\camera\\now.jpg')
        print('删除旧照片成功')
    cv2.imwrite('D:\StuForum1.0\img\camera\\now.jpg', frame)
    print('最新照片捕获成功')

def getMask():
    mask_detector = hub.Module(name="pyramidbox_lite_server_mask")
    # result = mask_detector.face_detection(images=[cv2.imread('../../img/camera/now.jpg')], visualization=True,
    #                                       output_dir='../../img/mask/')
    result = mask_detector.face_detection(images=[cv2.imread('D:\StuForum1.0\img\camera\\now.jpg')], visualization=True,
                                          output_dir='D:\StuForum1.0\img\mask\\')
    datas = result[0]['data']
    noMask = 0
    mask = 0
    for data in datas:
        if data['label'] == 'NO MASK':
            noMask += 1
        else:
            mask += 1
    print('mask:',mask)
    print('nomask:',noMask)
    print('total:',mask+noMask)
    imgName = result[0]['path'][:-2] + '.jpg'
    '''
    mask 戴口罩的人数
    noMask 不戴口罩的人数
    imgName 图片名称
    '''
    print('D:\StuForum1.0\img\mask\\'+ imgName)
    return mask,noMask,imgName
# mask()


def startCV():
    # with app.app_context():
    # 调用cv摄像头更新目前的图片
    getNowImg()
    # 调用算法检测口罩，及人数
    mask, noMask, imgName = getMask()
    total = mask + noMask
    # imgPath = 'D:\StuForum1.0\img\mask\\' + imgName
    imgPath = imgName
    imgPath = imgPath.encode('utf-8')
    if noMask != 0:
        behavior = BehaviorDaily(classroom='高一一班', behavior='未戴口罩', part=noMask, count=total, imgPath=imgPath)
        print('未戴口罩，高一一班未戴人数：', noMask, behavior)
    else:
        behavior = BehaviorDaily(classroom='高一一班', behavior='安全正常', part=noMask, count=total, imgPath=imgPath)
        print('安全正常，高一一班人数监测：', total, behavior)
    db.session.add(behavior)
    db.session.commit()
